#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
(root/'qa/repro-output.json').write_text(json.dumps({'status':'PASS','value':1},sort_keys=True,separators=(',',':'))+'\n')
