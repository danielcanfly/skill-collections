from __future__ import annotations
import copy, hashlib, importlib.util, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path
import pytest, yaml
from jsonschema import Draft202012Validator
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
EXAMPLE=ROOT/'examples'/'northstar-engineering-notes'/'config'

def run(args,cwd=None):
    return subprocess.run([str(x) for x in args],cwd=cwd,text=True,capture_output=True)

def safe_unzip(zp:Path,dest:Path)->Path:
    with zipfile.ZipFile(zp) as z:
        for i in z.infolist():
            p=Path(i.filename)
            assert not p.is_absolute() and '..' not in p.parts
            t=dest/i.filename;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(z.read(i))
    kids=[x for x in dest.iterdir() if x.is_dir()]
    assert len(kids)==1
    return kids[0]

def skill_root(tmp_path:Path,skill:str)->Path:
    zips=list((ROOT/'skills').glob(f'{skill}-*_1.0.0-public-beta3.zip'))
    assert len(zips)==1,zips
    return safe_unzip(zips[0],tmp_path/f'unpack-{skill}')

def copy_config(tmp_path:Path)->Path:
    d=tmp_path/'config';shutil.copytree(EXAMPLE,d);return d

def load_yaml(p): return yaml.safe_load(Path(p).read_text()) or {}
def dump_yaml(p,v): Path(p).write_text(yaml.safe_dump(v,sort_keys=False),encoding='utf-8')

def base_baton(status='READY',stage='fixture-producer',next_stage='skill01'):
    return {
      'schema_version':'1.1.0','workflow_id':'qual-workflow','current_stage':stage,'status':status,'next_stage':next_stage,
      'locales':{'primary':'en-US','enabled':['en-US','ja-JP'],'articles_by_locale':{'en-US':None,'ja-JP':None}},
      'series':{'name':'Systems','source':'user','part_number':1,'title_prefix':None,'locked':True,'planning_repo_snapshot':None},
      'publication':{'date':'2026-09-20','knowledge_cutoff':'2026-09-20','slug':'hello'},
      'freeze':{'prose_freeze_id':None,'publication_freeze_id':None},
      'routing':{'reopen_target':None,'reason_codes':[]},
      'counters':{'repair_cycle_count':0,'visual_generation_count':0,'visual_repair_count':0},
      'profile_snapshot':{'snapshot_sha256':'0'*64,'files':{f'f{i}':'0'*64 for i in range(5)}},
      'artifacts':[],'provenance':{}
    }

def build_handoff(skill:Path,workspace:Path,out:Path,profile:Path,producer='fixture-producer'):
    return run([sys.executable,skill/'scripts'/'build_handoff.py',workspace,out,'--producer-skill',producer,'--profile-dir',profile])

def validate_handoff(skill:Path,zp:Path,profile:Path):
    return run([sys.executable,skill/'scripts'/'validate_handoff.py',zp,'--profile-dir',profile])

def make_workspace(tmp_path:Path,baton=None)->Path:
    w=tmp_path/'workspace';w.mkdir(parents=True);(w/'BATON.json').write_text(json.dumps(baton or base_baton(),indent=2)+'\n');return w


def test_setup_example_valid():
    p=run([sys.executable,ROOT/'scripts'/'validate_setup.py','--config-dir',EXAMPLE])
    assert p.returncode==0,p.stdout+p.stderr
    assert 'PUBLICATION_PROFILE_VALID' in p.stdout

@pytest.mark.parametrize('mutator',[
    lambda c: c['deployment-policy'].update(mode='teleport'),
    lambda c: c['publication-profile']['languages'].update(primary='not_a_locale'),
    lambda c: c['editorial-policy']['research'].update(require_knowledge_cutoff=False),
    lambda c: c['deployment-policy']['rollback'].update(required=False,instructions=''),
    lambda c: c['visual-policy']['display_language'].update(strategy='martian'),
    lambda c: c['repository-profile']['paths'].update(content_path_template='../../{slug}/{locale_filename}'),
])
def test_setup_hostile_variants_rejected(tmp_path,mutator):
    d=copy_config(tmp_path); docs={n:load_yaml(d/f'{n}.yaml') for n in ['publication-profile','editorial-policy','visual-policy','repository-profile','deployment-policy']}; mutator(docs)
    for n,v in docs.items(): dump_yaml(d/f'{n}.yaml',v)
    p=run([sys.executable,ROOT/'scripts'/'validate_setup.py','--config-dir',d])
    assert p.returncode!=0
    assert 'PUBLICATION_PROFILE_INVALID' in p.stdout


def test_setup_repository_disabled_handoff_only_valid(tmp_path):
    d=copy_config(tmp_path); repo=load_yaml(d/'repository-profile.yaml');repo.update(enabled=False,repository=None,default_branch=None);repo['paths']['content_path_template']=None;repo['paths']['asset_path_template']=None;dump_yaml(d/'repository-profile.yaml',repo)
    dep=load_yaml(d/'deployment-policy.yaml');dep['mode']='handoff_only';dep['required_checks']=[];dump_yaml(d/'deployment-policy.yaml',dep)
    vis=load_yaml(d/'visual-policy.yaml');vis['enabled']=False;dump_yaml(d/'visual-policy.yaml',vis)
    p=run([sys.executable,ROOT/'scripts'/'validate_setup.py','--config-dir',d]);assert p.returncode==0,p.stdout+p.stderr


def test_baton_schema_accepts_generic_locales_and_series():
    schema=json.loads((ROOT/'BATON.schema.json').read_text());b=base_baton();errs=list(Draft202012Validator(schema).iter_errors(b));assert not errs,[e.message for e in errs]
    b2=base_baton();b2['locales']={'primary':'fr-FR','enabled':['fr-FR'],'articles_by_locale':{'fr-FR':None}};b2['series']['name']='Essais';assert not list(Draft202012Validator(schema).iter_errors(b2))


def test_handoff_valid_and_profile_bound(tmp_path):
    s=skill_root(tmp_path,'skill00');cfg=copy_config(tmp_path);w=make_workspace(tmp_path);out=tmp_path/'ok.zip';p=build_handoff(s,w,out,cfg);assert p.returncode==0,p.stderr
    v=validate_handoff(s,out,cfg);assert v.returncode==0,v.stdout+v.stderr
    (cfg/'voice-profile.md').write_text('changed after mint\n');v2=validate_handoff(s,out,cfg);assert v2.returncode!=0;assert 'profile snapshot mismatch' in (v2.stdout+v2.stderr)


def test_handoff_rejects_invalid_baton(tmp_path):
    s=skill_root(tmp_path,'skill00');cfg=copy_config(tmp_path);w=tmp_path/'workspace';w.mkdir(parents=True);(w/'BATON.json').write_text(json.dumps({'workflow_id':'x','status':'READY'}));p=build_handoff(s,w,tmp_path/'bad.zip',cfg);assert p.returncode!=0


def test_handoff_rejects_secret_and_symlink(tmp_path):
    s=skill_root(tmp_path,'skill00');cfg=copy_config(tmp_path)
    w=make_workspace(tmp_path/'a');(w/'.env').write_text('TEST_ONLY=not-a-secret\n');p=build_handoff(s,w,tmp_path/'secret.zip',cfg);assert p.returncode!=0;assert 'secret' in (p.stdout+p.stderr).lower()
    w2=make_workspace(tmp_path/'b');outside=tmp_path/'outside.txt';outside.write_text('outside');os.symlink(outside,w2/'leaked.txt');p2=build_handoff(s,w2,tmp_path/'link.zip',cfg);assert p2.returncode!=0;assert 'symlink' in (p2.stdout+p2.stderr).lower()


def test_handoff_rejects_unlisted_member(tmp_path):
    s=skill_root(tmp_path,'skill00');cfg=copy_config(tmp_path);w=make_workspace(tmp_path);out=tmp_path/'ok.zip';assert build_handoff(s,w,out,cfg).returncode==0
    with zipfile.ZipFile(out,'a') as z:z.writestr('UNLISTED_INJECTION.txt','x')
    v=validate_handoff(s,out,cfg);assert v.returncode!=0;assert 'member-set mismatch' in (v.stdout+v.stderr)


def test_repair_hard_limit_routes_to_end(tmp_path):
    s=skill_root(tmp_path,'skill00');cfg=copy_config(tmp_path);b=base_baton('EVALUATION_FAILED','skill05','skill06');b['routing']['reopen_target']='skill06';b['counters']['repair_cycle_count']=2;w=make_workspace(tmp_path,b);inp=tmp_path/'in.zip';out=tmp_path/'out.zip';assert build_handoff(s,w,inp,cfg).returncode==0
    p=run([sys.executable,s/'scripts'/'route_from_graph.py',inp,out,'--profile-dir',cfg]);assert p.returncode==0,p.stdout+p.stderr;r=json.loads(p.stdout);assert r['next_stage']=='END';assert r['hard_limit_block']=='REPAIR_CEILING_REACHED'


def test_visual_language_binding_uses_article_locale(tmp_path):
    s=skill_root(tmp_path,'skill08');cfg=copy_config(tmp_path);spec=tmp_path/'spec.json';spec.write_text(json.dumps({'text_contract':{'visible_text_whitelist':['こんにちは']}}))
    p=run([sys.executable,s/'scripts'/'language_audit_bind.py',spec,'--visual-policy',cfg/'visual-policy.yaml','--publication-profile',cfg/'publication-profile.yaml','--article-locale','ja-JP','--status','PASS','--confirm-semantic-review']);assert p.returncode==0,p.stdout+p.stderr
    assert json.loads(spec.read_text())['text_contract']['display_language']=='ja-JP'


def make_repo(tmp_path:Path,cfg:Path)->Path:
    repo=tmp_path/'repo';(repo/'content/posts/hello').mkdir(parents=True);(repo/'public/images/hello').mkdir(parents=True)
    fm='---\ntitle: Hello\ndescription: Test\ndate: 2026-09-20\ncategories: [Engineering]\ntags: [Test]\nseries: Systems\nseriesOrder: 1\ncoverImage: /public/images/hello/figure.webp\n---\n\n![Figure](/public/images/hello/figure.webp)\n'
    (repo/'content/posts/hello/en.md').write_text(fm);(repo/'content/posts/hello/ja.md').write_text(fm.replace('title: Hello','title: こんにちは'))
    Image.new('RGB',(20,20)).save(repo/'public/images/hello/figure.webp','WEBP')
    return repo


def test_generic_publish_qa_and_release_include_assets(tmp_path):
    cfg=copy_config(tmp_path);repo=make_repo(tmp_path,cfg);s10=skill_root(tmp_path,'skill10');s11=skill_root(tmp_path,'skill11')
    q=run([sys.executable,s10/'scripts'/'validate_publish_bundle.py','--bundle',repo,'--slug','hello','--config-dir',cfg]);assert q.returncode==0,q.stdout+q.stderr;assert json.loads(q.stdout)['pass'] is True
    out=tmp_path/'release.zip';r=run([sys.executable,s11/'scripts'/'build_release_handoff.py','--repo-root',repo,'--config-dir',cfg,'--slug','hello','--output-zip',out,'--base-sha','abc123','--blocker','owner-approval']);assert r.returncode==0,r.stdout+r.stderr
    with zipfile.ZipFile(out) as z:
        names=set(z.namelist()); assert any(n.endswith('/content/posts/hello/en.md') for n in names);assert any(n.endswith('/content/posts/hello/ja.md') for n in names);assert any(n.endswith('/public/images/hello/figure.webp') for n in names)


def test_no_private_owner_or_legacy_fixed_language_markers():
    needles=['CODEX_RELEASE_HANDOFF_READY','bilingual','zh-only','en-only']
    allowed_ext={'.md','.json','.yaml','.yml','.py','.txt'}
    hits=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in allowed_ext or 'qualification' in p.parts: continue
        try:t=p.read_text(encoding='utf-8').lower()
        except Exception:continue
        for n in needles:
            if n.lower() in t:hits.append((str(p.relative_to(ROOT)),n))
    assert not hits,hits
