# Security boundary

Public Beta3 uses fail-closed handoff packaging. Runtime handoffs reject symlinks, path traversal, duplicate ZIP members, undeclared ZIP members, secret-like paths, and high-confidence secret literals. Baton and handoff manifests are JSON-Schema validated, `SHA256SUMS` is exact-inventory checked, and the active publication profile is SHA-256 bound into every baton.

Do not place credentials, `.env` files, private keys, auth headers or raw production incident bundles in a stage workspace. Use external secret managers/tool authorization.
