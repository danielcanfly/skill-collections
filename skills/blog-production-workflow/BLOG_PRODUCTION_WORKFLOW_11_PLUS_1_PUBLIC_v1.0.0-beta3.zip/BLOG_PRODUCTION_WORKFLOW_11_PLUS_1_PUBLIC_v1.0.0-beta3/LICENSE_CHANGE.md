# License change

Public Beta3 is a licensing-only rebuild of the qualified Public Beta2 behavior.

- Current license: **Apache License 2.0**
- Public Beta2 was previously distributed under the MIT License. Copies already obtained under MIT remain governed by that license.
- Runtime behavior, schemas, safety gates, and publication-profile semantics are unchanged from the qualified Beta2 implementation.
- Each nested Skill package now carries its own Apache-2.0 LICENSE file so it can be redistributed independently with clear terms.
