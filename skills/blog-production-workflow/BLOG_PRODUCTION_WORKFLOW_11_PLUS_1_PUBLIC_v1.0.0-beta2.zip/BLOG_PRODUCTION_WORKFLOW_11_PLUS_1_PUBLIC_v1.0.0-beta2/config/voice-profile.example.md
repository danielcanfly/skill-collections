# Publication voice profile

Replace this file with the publication's real house voice before using voice-sensitive drafting/evaluation.

## Audience
- Who is the reader?
- What can they safely be assumed to know?

## Voice
- Desired qualities:
- Undesired qualities:
- Sentence/rhythm preferences:
- Technical terminology policy:
- First-person / second-person policy:

## Evidence and certainty
- How should uncertainty be expressed?
- What kinds of claims require citations?

## AI-residue rules
- Phrases/patterns to avoid:
- Formatting tendencies to avoid:

## Locale-specific guidance
Reference separate style guides from `publication-profile.yaml` when needed.
