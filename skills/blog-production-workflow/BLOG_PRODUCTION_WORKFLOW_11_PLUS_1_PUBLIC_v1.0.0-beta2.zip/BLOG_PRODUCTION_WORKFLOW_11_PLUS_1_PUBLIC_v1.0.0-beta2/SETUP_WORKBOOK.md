# Setup Workbook

Complete this once for each publication. The workflow intentionally ships without the original owner's private identity, repository topology, house voice, languages, series registry or deployment assumptions.

## A. Publication identity → `config/publication-profile.yaml`
| Question | Required? | Config field |
|---|---:|---|
| What is the publication/site name? | Yes | `publication.name` |
| What author/brand name should be visible? | Yes | `publication.author_display_name` |
| What timezone governs editorial dates? | Yes | `publication.default_timezone` |
| What is the primary BCP-47 locale? | Yes | `languages.primary` |
| Are additional locales published? | No | `languages.additional` |
| What filename maps to each locale? | If repo integration | `languages.article_filename_by_locale` |
| Where is the house voice profile? | For voice-sensitive stages | `voice.profile_path` |

## B. Editorial policy → `config/editorial-policy.yaml`
| Question | Required? | Config field |
|---|---:|---|
| Does the publication use series? | Yes | `series.enabled` |
| Existing allowed series? | If enabled | `series.allowed_series` |
| May the workflow create a new series? | If enabled | `series.allow_new_series` |
| May it infer a series when unspecified? | If enabled | `series.infer_when_unspecified` |
| What is the visible title format? | Yes | `series.title_format` |
| Is Part/order numbering used? | If enabled | `series.numbering.*` |
| What slug convention is required? | Yes | `slug.policy` |
| Is a knowledge cutoff mandatory? | Yes | `research.require_knowledge_cutoff` |

## C. Visual policy → `config/visual-policy.yaml`
| Question | Required? | Config field |
|---|---:|---|
| Are article visuals enabled? | Yes | `enabled` |
| Which locale should visible figure text use? | If enabled | `display_language.*` |
| What master format is used during visual QA? | If enabled | `master.format` |
| What raster format is deployable? | If enabled | `publication.raster_format` |
| Are other raster formats forbidden? | If enabled | `publication.forbid_other_raster_formats` |

## D. Repository integration → `config/repository-profile.yaml`
| Question | Required? | Config field |
|---|---:|---|
| Should the workflow inspect a live repository? | Yes | `enabled` |
| Provider and repository identifier? | If enabled | `provider`, `repository` |
| Default/base branch? | If enabled | `default_branch` |
| Article destination template? | If enabled | `paths.content_path_template` |
| Asset destination template? | If enabled | `paths.asset_path_template` |
| Where are series/category registries? | If used | `paths.*_registry_paths` |
| What frontmatter is mandatory? | Yes | `frontmatter.*` |

## E. Release/deployment policy → `config/deployment-policy.yaml`
| Question | Required? | Config field |
|---|---:|---|
| Handoff only, manual, PR+CI, or custom? | Yes | `mode` |
| Hosting provider? | Yes | `hosting_provider` |
| Required CI checks? | For PR+CI | `required_checks` |
| Staging workflow/path? | If used | `staging.*` |
| Production workflow/path? | If used | `production.*` |
| Is explicit publish authorization required? | Yes | `production.require_explicit_authorization` |
| What is the rollback method? | Yes | `rollback.*` |

## F. Voice profile
Fill `config/voice-profile.md`. Do not put credentials, private keys, access tokens, unpublished personal data or confidential production evidence into a public profile.

## Validation
1. Copy every `*.example.*` file to the same name without `.example`.
2. Fill required values.
3. Run `python scripts/validate_setup.py --config-dir config`.
4. Start Skill00 only after it prints `PUBLICATION_PROFILE_VALID`.
