# Getting started

1. Read `SETUP_WORKBOOK.md`.
2. Copy `config/*.example.*` to active config filenames and complete them.
3. Run `python scripts/validate_setup.py --config-dir config`.
4. Install/use Skill00 as the router and Skill01–11 as independent workers.
5. Every stage consumes and emits a ZIP handoff. Keep large artifacts in the ZIP, not graph state.
6. Use the release stage in `handoff_only` mode unless you deliberately configure an authorised deployment adapter.

The normal path remains:
`01 Research → 02 Editorial Plan → 03 Architecture → 04 Draft → 05 Evaluator → 07 Visual Brief → 08 Visual Generation → 09 Visual Acceptance → 10 Publish QA → 11 Release Handoff`.
Skill06 is entered only by evaluator repair routing. Skill00 routes but does not perform production-stage work.
