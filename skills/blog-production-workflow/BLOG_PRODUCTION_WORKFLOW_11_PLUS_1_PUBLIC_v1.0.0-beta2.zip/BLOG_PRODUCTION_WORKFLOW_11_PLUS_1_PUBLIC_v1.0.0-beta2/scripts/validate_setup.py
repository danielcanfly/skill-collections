#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path, PurePosixPath
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import yaml
from jsonschema import Draft202012Validator

NAMES=['publication-profile','editorial-policy','visual-policy','repository-profile','deployment-policy']
LOCALE_RX=re.compile(r'^[A-Za-z]{2,3}(?:-[A-Za-z]{4})?(?:-(?:[A-Za-z]{2}|[0-9]{3}))?(?:-[A-Za-z0-9]{5,8})*$')

def load_yaml(p):
    with p.open(encoding='utf-8') as f:return yaml.safe_load(f) or {}
def fail(errors):
    print('PUBLICATION_PROFILE_INVALID')
    for e in errors: print('- '+e)
    return 1
def safe_template(value,label,required_tokens):
    errs=[]
    if not isinstance(value,str) or not value.strip(): return [f'REQUIRED_VALUE_MISSING:{label}']
    if '\\' in value or value.startswith('/') or '..' in PurePosixPath(value).parts: errs.append(f'UNSAFE_PATH_TEMPLATE:{label}')
    allowed={'slug','locale','locale_filename','filename'}
    tokens=set(re.findall(r'{([A-Za-z_][A-Za-z0-9_]*)}',value))
    if not tokens.issubset(allowed): errs.append(f'UNKNOWN_PATH_TEMPLATE_TOKEN:{label}:{sorted(tokens-allowed)}')
    for t in required_tokens:
        if t not in tokens: errs.append(f'PATH_TEMPLATE_MISSING_TOKEN:{label}:{t}')
    return errs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config-dir',type=Path,default=Path('config')); a=ap.parse_args(); c=a.config_dir.resolve(); errors=[]; docs={}
    schema_dir=Path(__file__).resolve().parents[1]/'schemas'/'config'
    for n in NAMES:
        p=c/f'{n}.yaml'
        if not p.is_file(): errors.append(f'MISSING_CONFIG:{p.name}'); continue
        try: docs[n]=load_yaml(p)
        except Exception as e: errors.append(f'YAML_PARSE_ERROR:{p.name}:{e}'); continue
        schema=json.loads((schema_dir/f'{n}.schema.json').read_text())
        for e in sorted(Draft202012Validator(schema).iter_errors(docs[n]),key=lambda x:list(x.path)):
            errors.append(f'SCHEMA:{p.name}:{"/".join(map(str,e.path)) or "$"}:{e.message}')
    if errors: return fail(errors)
    pub,ed,vis,repo,dep=[docs[n] for n in NAMES]
    primary=pub['languages']['primary']; additional=pub['languages']['additional']; locales=[primary]+additional
    if primary in additional: errors.append('PRIMARY_LOCALE_DUPLICATED_IN_ADDITIONAL')
    mode=pub['publication']['publication_mode']
    if mode=='single' and additional: errors.append('SINGLE_MODE_FORBIDS_ADDITIONAL_LOCALES')
    if mode=='multilingual' and not additional: errors.append('MULTILINGUAL_REQUIRES_ADDITIONAL_LOCALE')
    try: ZoneInfo(pub['publication']['default_timezone'])
    except ZoneInfoNotFoundError: errors.append('INVALID_IANA_TIMEZONE')
    for loc in locales:
        if not LOCALE_RX.fullmatch(loc): errors.append('INVALID_LOCALE:'+loc)
    if ed['series']['enabled'] and not ed['series']['allowed_series'] and not ed['series']['allow_new_series']:
        errors.append('SERIES_ENABLED_WITH_NO_ALLOWED_SERIES_AND_CREATION_DISABLED')
    if vis['display_language']['strategy']=='fixed':
        fixed=vis['display_language']['fixed_locale']
        if not isinstance(fixed,str) or not LOCALE_RX.fullmatch(fixed): errors.append('FIXED_VISUAL_LANGUAGE_REQUIRES_VALID_LOCALE')
    elif vis['display_language']['fixed_locale'] is not None:
        errors.append('FIXED_LOCALE_ONLY_ALLOWED_WITH_FIXED_STRATEGY')
    if repo['enabled']:
        if not repo['repository']: errors.append('REQUIRED_VALUE_MISSING:repository.repository')
        if not repo['default_branch']: errors.append('REQUIRED_VALUE_MISSING:repository.default_branch')
        errors += safe_template(repo['paths']['content_path_template'],'repository.paths.content_path_template',{'slug','locale_filename'})
        errors += safe_template(repo['paths']['asset_path_template'],'repository.paths.asset_path_template',{'slug','filename'})
        mapping=pub['languages']['article_filename_by_locale']
        for loc in locales:
            if loc not in mapping: errors.append('LOCALE_FILENAME_MAPPING_MISSING:'+loc)
        for group in ('series_registry_paths','category_registry_paths'):
            for i,p in enumerate(repo['paths'][group]): errors += safe_template(p,f'repository.paths.{group}[{i}]',set())
    if dep['mode']=='pr_ci' and not dep['required_checks']: errors.append('PR_CI_MODE_REQUIRES_REQUIRED_CHECKS')
    if not dep['rollback']['instructions'].strip(): errors.append('ROLLBACK_INSTRUCTIONS_REQUIRED')
    voice=(c.parent/pub['voice']['profile_path']).resolve()
    try: voice.relative_to(c.parent.resolve())
    except ValueError: errors.append('VOICE_PROFILE_PATH_ESCAPES_CONFIG_ROOT')
    if not voice.is_file():
        alt=c/Path(pub['voice']['profile_path']).name
        if not alt.is_file(): errors.append('VOICE_PROFILE_NOT_FOUND:'+pub['voice']['profile_path'])
    for loc,p in pub['voice']['locale_style_guides'].items():
        if not LOCALE_RX.fullmatch(loc): errors.append('INVALID_STYLE_GUIDE_LOCALE:'+loc)
        q=(c.parent/p).resolve()
        try:q.relative_to(c.parent.resolve())
        except ValueError: errors.append('STYLE_GUIDE_PATH_ESCAPES_CONFIG_ROOT:'+p)
    if errors:return fail(errors)
    print('PUBLICATION_PROFILE_VALID');return 0
if __name__=='__main__': raise SystemExit(main())
