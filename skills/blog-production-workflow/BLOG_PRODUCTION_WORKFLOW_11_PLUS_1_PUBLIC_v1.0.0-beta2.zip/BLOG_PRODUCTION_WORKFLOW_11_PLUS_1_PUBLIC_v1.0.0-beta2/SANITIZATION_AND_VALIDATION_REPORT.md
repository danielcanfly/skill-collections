# Sanitization and validation report

Status: `PUBLIC_BETA2_QUALIFICATION_PASS`

## Sanitization scope

The public derivative removes owner-specific publication identity, private repository identifiers/topology defaults, private CI/deployment/hosting defaults, private voice calibration corpora, and fixed language/series/title assumptions. Equivalent capabilities are exposed through the setup workbook and profile files rather than silently deleted.

The final distributable scan returned zero owner-identity/private-repository residue and zero high-confidence credential findings outside the security scanner/test machinery.

## Functional generalization

The removed private values are represented by:

- `publication-profile.yaml`
- `editorial-policy.yaml`
- `visual-policy.yaml`
- `repository-profile.yaml`
- `deployment-policy.yaml`
- `voice-profile.md`

The setup validator is schema-backed and fails closed on invalid deployment modes, malformed locales, disabled mandatory knowledge-cutoff policy, unsafe repository path templates, invalid visual-language strategies, and rollback-policy weakening.

Baton handoffs use arbitrary BCP-47 locale sets and arbitrary series names. Skill10/11 resolve article and asset destinations from the active repository profile rather than from a bundled site layout. Release packaging includes referenced publication assets.

## Handoff security

Handoff building and validation reject:

- `.env` and other secret-like paths;
- high-confidence secret literals;
- symlinks and ZIP symlink members;
- absolute/path-traversal paths;
- duplicate or undeclared ZIP members;
- manifest/checksum mismatches;
- Baton JSON-Schema violations;
- active-profile hash drift.

## Fresh Beta2 qualification

- Skill packages: **12 / 12 PASS**
- Package-native tests: **51 passed**
- Public hostile regression tests: **17 passed**
- Total executable tests: **68 passed**
- Static distributable checks: **16 / 16 PASS**
- Fresh extra profile: `fr-FR`, custom `Essais` series, alternate article/asset paths → `PUBLICATION_PROFILE_VALID`
- JSON parse errors: **0**
- JSON-Schema meta-validation errors: **0**
- Python compile errors: **0**
- Package-manifest integrity errors: **0**
- SHA-256 inventory errors: **0**
- Source-to-packaged Skill ZIP mismatches: **0**
- `.pytest_cache`, `__pycache__`, `.pyc`, `.DS_Store` in distributable: **0**

## Licensing

The public derivative now ships under the **MIT License**.
