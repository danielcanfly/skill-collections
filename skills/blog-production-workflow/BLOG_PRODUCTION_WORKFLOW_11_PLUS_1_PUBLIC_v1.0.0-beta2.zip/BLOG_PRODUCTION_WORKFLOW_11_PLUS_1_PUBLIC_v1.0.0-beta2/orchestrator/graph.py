from __future__ import annotations
from pathlib import Path
from typing import TypedDict,Callable,Any
import json
from langgraph.graph import StateGraph,START,END
class BlogState(TypedDict,total=False):
    workflow_id:str;status:str;current_stage:str;next_stage:str|None;handoff_zip:str;reopen_target:str|None;repair_cycle_count:int;visual_generation_count:int;visual_repair_count:int;profile_dir:str
StageInvoker=Callable[[str,str|None,BlogState],dict[str,Any]]
STAGES={f'skill{i:02d}' for i in range(1,12)}
def _matches_when(edge,state):return all(state.get(k)==v for k,v in (edge.get('when') or {}).items())
def _hard_limit(graph,state):
    h=graph.get('hard_limits') or {};frm=state.get('current_stage');st=state.get('status');rt=state.get('reopen_target')
    if frm=='skill05' and st=='EVALUATION_FAILED' and rt=='skill06' and state.get('repair_cycle_count',0)>=h.get('repair_humanizer_max_cycles',2):return END
    if frm=='skill09' and st=='ARTICLE_FIT_FAILED' and rt=='skill08' and state.get('visual_repair_count',0)>=h.get('visual_bounded_repairs_max',1):return END
    if frm=='skill08' and st=='VISUAL_REPLAN' and state.get('visual_generation_count',0)>=h.get('visual_generation_initial_attempts',1)+h.get('visual_bounded_repairs_max',1):return END
    return None
def resolve_next_stage(graph,state):
    block=_hard_limit(graph,state)
    if block is not None:return block
    frm=state.get('current_stage');status=state.get('status')
    for edge in graph.get('edges',[]):
        if edge.get('from')==frm and edge.get('on')==status and _matches_when(edge,state):
            if edge.get('route_from_baton'):
                target=state.get('reopen_target') or state.get('next_stage')
                if target in STAGES:return target
                if target in {None,'END'}:return END
                raise ValueError(f'Illegal route_from_baton target for {frm}/{status}: {target!r}')
            target=edge.get('to');return END if target in {None,'END'} else target
    for term in graph.get('terminal_states',[]):
        if term.get('from')==frm and term.get('on')==status:return END
    raise ValueError(f'No WORKFLOW_GRAPH route for {frm}/{status}')
def build_graph(skill_root,invoke_stage):
    skill_root=Path(skill_root);contract=json.loads((skill_root/'skill00-blog-workflow-map'/'contracts'/'WORKFLOW_GRAPH.json').read_text());g=StateGraph(BlogState)
    for sid in sorted(STAGES):
        def make_node(stage_id):
            def node(state):return invoke_stage(stage_id,state.get('handoff_zip'),state)
            return node
        g.add_node(sid,make_node(sid))
    g.add_edge(START,'skill01')
    def route(state):return resolve_next_stage(contract,state)
    for sid in sorted(STAGES):g.add_conditional_edges(sid,route,[*sorted(STAGES),END])
    return g.compile()
