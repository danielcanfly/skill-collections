# Local LangGraph scaffold

Unzip the 12 skill packages under one local `skills/` directory. Instantiate `LocalSkillRunner` with an executor that knows how to call your chosen LLM/tools. Pass `runner.run` through a small adapter as `invoke_stage` to `build_graph`. The graph stores only control metadata; each stage stores durable artifacts in its handoff ZIP.
