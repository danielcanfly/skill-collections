from __future__ import annotations
from pathlib import Path
import json,os,subprocess,sys

class LocalSkillRunner:
    """Filesystem contract runner. LLM/tool execution is injected through `executor`."""
    def __init__(self, skill_root: str | Path, executor):
        self.skill_root=Path(skill_root);self.executor=executor
    def skill_dir(self,skill_id:str)->Path:
        matches=list(self.skill_root.glob(f'{skill_id}-*'))
        if len(matches)!=1:raise RuntimeError(f'Expected one local directory for {skill_id}, got {matches}')
        return matches[0]
    def run(self,skill_id:str,handoff_zip:str|None,state:dict)->dict:
        d=self.skill_dir(skill_id);contract=json.loads((d/'contracts'/'STAGE_CONTRACT.json').read_text())
        if handoff_zip:
            profile_dir=state.get('profile_dir')
            if not profile_dir:raise RuntimeError('profile_dir is required for profile-bound handoff validation')
            cmd=[sys.executable,str(d/'scripts'/'validate_handoff.py'),str(handoff_zip),'--profile-dir',str(profile_dir)]
            for status in contract['accepts']:
                if status!='ANY_VALID_BATON':cmd += ['--accepted-status',status]
            env=dict(os.environ);env['PYTHONPATH']=str(d/'scripts')+os.pathsep+env.get('PYTHONPATH','')
            cp=subprocess.run(cmd,capture_output=True,text=True,env=env)
            if cp.returncode!=0:raise RuntimeError('handoff validation failed: '+(cp.stderr or cp.stdout).strip())
        result=self.executor(skill_dir=d,handoff_zip=handoff_zip,state=state)
        if result.get('status') not in contract['emits']:raise RuntimeError(f"{skill_id} emitted illegal status {result.get('status')}")
        return result
