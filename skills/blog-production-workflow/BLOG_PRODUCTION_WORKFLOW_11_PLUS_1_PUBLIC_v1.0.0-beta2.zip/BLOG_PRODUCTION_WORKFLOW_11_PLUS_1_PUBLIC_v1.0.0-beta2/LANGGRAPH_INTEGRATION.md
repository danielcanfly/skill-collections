# LangGraph integration

The orchestrator derives every transition from `WORKFLOW_GRAPH.json`. Local graph code parses edges, route-from-baton rules, and terminal/operator states from that single machine-readable contract. It must not route from ad hoc `next_stage` values unless the graph explicitly marks the state `route_from_baton`.
