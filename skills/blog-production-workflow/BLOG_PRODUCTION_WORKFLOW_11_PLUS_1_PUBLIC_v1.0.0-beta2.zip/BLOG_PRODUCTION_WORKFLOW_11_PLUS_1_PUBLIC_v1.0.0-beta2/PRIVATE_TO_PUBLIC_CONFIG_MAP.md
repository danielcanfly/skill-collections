# Private-to-public configuration map

The public build follows one rule: **generalize, do not amputate**. Every owner-specific capability removed from the private source is replaced by an explicit configuration surface.

| Removed private assumption | Public replacement | Consumed by |
|---|---|---|
| Publication/owner identity | `publication-profile.yaml → publication.*` | all stages / release metadata |
| Fixed publication locales | `publication-profile.yaml → languages.*` | 02, 04, 05, 06, 10, 11 |
| Private house voice and calibration corpus | `voice-profile.md` + optional locale guides | 04, 05, 06 |
| Fixed series registry | `editorial-policy.yaml → series.*` | 02, 04, 05, 10, 11 |
| Fixed title/Part convention | `editorial-policy.yaml → series.title_format/numbering` | 02, 04, 10, 11 |
| Private repository identifier | `repository-profile.yaml → repository` | 02, 10, 11 |
| Fixed content/asset directories | `repository-profile.yaml → paths.*_template` | 10, 11 |
| Fixed series/category registry files | `repository-profile.yaml → paths.*_registry_paths` | 02, 10, 11 |
| Fixed frontmatter expectations | `repository-profile.yaml → frontmatter.*` | 10, 11 |
| Fixed CI gate | `deployment-policy.yaml → required_checks` | 11 |
| Fixed hosting/deploy workflows | `deployment-policy.yaml → hosting/staging/production` | 11 |
| Fixed visual display language | `visual-policy.yaml → display_language.*` | 07, 08, 09 |
| Fixed deployable image-format policy | `visual-policy.yaml → publication.*` | 08, 09, 10, 11 |

No original private values are reproduced in this document.
