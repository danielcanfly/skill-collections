# Northstar voice profile

- Clear, technically precise, calm, and concrete.
- Prefer operational examples over slogans.
- State uncertainty and evidence boundaries explicitly.
- Avoid inflated claims, generic motivational endings, and decorative jargon.
- Write each locale natively rather than translating sentence geometry.
