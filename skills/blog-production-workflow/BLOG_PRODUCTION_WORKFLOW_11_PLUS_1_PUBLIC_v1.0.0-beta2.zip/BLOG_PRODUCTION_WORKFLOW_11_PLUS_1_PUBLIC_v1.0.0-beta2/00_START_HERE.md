# Blog Production Workflow 11 + 1 — Public Beta

A profile-driven, reusable editorial production workflow. Install/use Skill00 as the map and Skill01–11 as independent workers. Every stage consumes and emits a ZIP handoff.

**Before Skill00:** complete `SETUP_WORKBOOK.md`, create active config files, and run `python scripts/validate_setup.py --config-dir config`.

Normal path: 01 Research → 02 Editorial Plan → 03 Architecture → 04 Draft → 05 Evaluator → 07 Visual Brief → 08 Visual Generation → 09 Visual Acceptance → 10 Publish QA → 11 Release Handoff. Skill06 is entered only by evaluator repair routing. Skill00 routes but never performs stage work.

Status: **Public Beta**. This derivative has been sanitized and mechanically validated, but it has not received the fresh independent hostile qualification required for Stable/GA.
